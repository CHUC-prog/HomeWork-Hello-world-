﻿using System;

class Program
{
    static void Main(string[] args)
    {
        string[] stethem = {
            "Сила – не в бабках. Ведь бабки – уже старые.",
            "Взял нож - режь, взял дошик - ешь.",
            "Я живу, как карта ляжет. Ты живёшь, как мамка скажет.",
            "Никогда не сдавайтесь, идите к своей цели! А если будет сложно – сдавайтесь.",
            "Если заблудился в лесу, иди домой.",
            "Запомни: всего одна ошибка – и ты ошибся.",
            "Я вам запрещаю срать!",
            "Делай, как надо. Как не надо, не делай.",
            "Марианскую впадину знаешь? Это я упал."
        };

        string[] dota2 = {
            "Кидай хук, а не пацанов.",
            "Поставь пятерку зае*&бал_)))",
            "Рапиру трудно найти, легко потерять, и невозможно разбить.",
            "Не тот Керри кто крипов добивал, а тот кто трон не просрал.",
            "Лучше с пацанами под фонтан, чем с чертями в трон.",
            "Если фармить, то лес, если вардить, то мид, если гангать, то с огнём в сердце.",
            "Каждый может добить крипа, но не каждый может добить за крипа.",
            "Кидай пацанов, а не хук."
        };

        while (true)
        {
            Console.WriteLine("Цитаты:");
            Console.WriteLine("1. Джейсон Стетхем.");
            Console.WriteLine("2. То, что я ненавижу");
            Console.WriteLine("3. Из доты 2");

            Console.Write("Выберите номер: ");
            int personNumber;
            while (!int.TryParse(Console.ReadLine(), out personNumber) || personNumber < 1 || personNumber > 3)
            {
                Console.WriteLine("Некорректный ввод.");
                Console.Write("Выберите номер: ");
            }

            Random random = new Random();
            int randomIndex = random.Next(0, 9);

            switch (personNumber)
            {
                case 1:
                    Console.WriteLine($"Случайная цитата Джейсона Стетхема: {stethem[randomIndex]}");
                    break;
                case 2:
                    Console.WriteLine($"Случайная цитата того чего я ненавижу:");
                    Console.WriteLine("Программирование!!!");
                    Console.WriteLine("Программирование!!!");
                    Console.WriteLine("Программирование!!!");
                    Console.WriteLine("Программирование!!!");
                    Console.WriteLine("Программирование!!!");
                    Console.WriteLine("Программирование!!!");
                    Console.WriteLine("Программирование!!!");
                    Console.WriteLine("Программирование!!!");
                    break;
                case 3:
                    Console.WriteLine($"Случайная цитата из доты 2: {dota2[randomIndex]}");
                    break;
                default:
                    Console.WriteLine("Неверный ввод!");
                    break;
            }
            Console.ReadLine();
            Console.Clear();
        }

       
    }
}